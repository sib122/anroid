package com.example.simbypasstest

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.TelephonyManager
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val infoView = findViewById<TextView>(R.id.simInfo)
        val telephonyManager = getSystemService(TELEPHONY_SERVICE) as TelephonyManager

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_PHONE_STATE), 0)
        }

        val simState = telephonyManager.simState
        val simReady = simState == TelephonyManager.SIM_STATE_READY

        if (BuildConfig.DEBUG) {
            infoView.text = "Debug build: SIM check bypassed ✅"
        } else {
            if (simReady) {
                val carrier = telephonyManager.networkOperatorName ?: "Unknown"
                infoView.text = "SIM Ready - Carrier: $carrier"
            } else {
                Toast.makeText(this, "No SIM found!", Toast.LENGTH_SHORT).show()
                infoView.text = "No SIM detected ❌"
            }
        }
    }
}
